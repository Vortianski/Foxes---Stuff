package xox.labvorty.foxes_and_stuff.data.events;

import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.registry.CreativeTabRegistry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.fox.Fox;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import xox.labvorty.foxes_and_stuff.FoxPlatform;
import xox.labvorty.foxes_and_stuff.FoxesAndStuffMod;
import xox.labvorty.foxes_and_stuff.data.holder.ModdedFoxVariants;
import xox.labvorty.foxes_and_stuff.init.FoxesStuffItems;
import xox.labvorty.foxes_and_stuff.items.FoxSpeciesRoll;
import xox.labvorty.foxes_and_stuff.mixin_helpers.TameableFox;

public class FoxEvents {
    public static final TagKey<Item> FOX_TAMING_ITEMS = TagKey.create(Registries.ITEM, FoxesAndStuffMod.location("fox_taming_items"));

    public static void init() {
        if (FoxPlatform.get().usesArchitecturyEntityInteraction()) {
            InteractionEvent.INTERACT_ENTITY.register((player, entity, hand) ->
                    handleEntityInteraction(player, entity, hand) ? EventResult.interruptTrue() : EventResult.pass());
        }
        CreativeTabRegistry.modify(
                CreativeTabRegistry.defer(CreativeModeTabs.COMBAT),
                (flags, output, canUseGameMasterBlocks) -> {
                    output.acceptAfter(
                            Items.DIAMOND_HORSE_ARMOR,
                            FoxesStuffItems.LEATHER_FOX_ARMOR.get(),
                            CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS
                    );
                    output.acceptAfter(
                            FoxesStuffItems.LEATHER_FOX_ARMOR.get(),
                            FoxesStuffItems.IRON_FOX_ARMOR.get(),
                            CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS
                    );
                    output.acceptAfter(
                            FoxesStuffItems.IRON_FOX_ARMOR.get(),
                            FoxesStuffItems.GOLD_FOX_ARMOR.get(),
                            CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS
                    );
                    output.acceptAfter(
                            FoxesStuffItems.GOLD_FOX_ARMOR.get(),
                            FoxesStuffItems.DIAMOND_FOX_ARMOR.get(),
                            CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS
                    );
                    output.acceptAfter(
                            FoxesStuffItems.DIAMOND_FOX_ARMOR.get(),
                            FoxesStuffItems.NETHERITE_FOX_ARMOR.get(),
                            CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS
                    );
                }
        );

        CreativeTabRegistry.modify(
                CreativeTabRegistry.defer(CreativeModeTabs.FOOD_AND_DRINKS),
                (flags, output, canUseGameMasterBlocks) -> output.acceptAfter(
                        Items.SWEET_BERRIES,
                        FoxesStuffItems.GOLDEN_BERRIES.get(),
                        CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS
                )
        );
    }

    public static boolean handleEntityInteraction(Player player, Entity entity, InteractionHand hand) {
        if (!(entity instanceof Fox fox) || !(fox instanceof TameableFox tf)) return false;
        if (hand != InteractionHand.MAIN_HAND) return false;

        ItemStack stack = player.getItemInHand(hand);
        boolean client = fox.level().isClientSide();

        if (!tf.foxesstuff$isFoxTame()) {
            if (stack.is(FOX_TAMING_ITEMS) && !fox.isBaby()) {
                if (!client) {
                    stack.consume(1, player);
                    ServerLevel level = (ServerLevel) fox.level();
                    if (fox.getRandom().nextInt(3) == 0) {
                        tf.foxesstuff$tameFox(player);
                        level.sendParticles(ParticleTypes.HEART, fox.getX(), fox.getY(0.7), fox.getZ(), 7, 0.4, 0.4, 0.4, 0.02);
                    } else {
                        level.sendParticles(ParticleTypes.SMOKE, fox.getX(), fox.getY(0.7), fox.getZ(), 7, 0.4, 0.4, 0.4, 0.02);
                    }
                }

                return true;
            }

            return false;
        }

        if (stack.getItem() instanceof FoxSpeciesRoll) {
            // Requires baby texture redraw.
            if (fox.isBaby()) return true;

            if (!client) {
                handleCustomFood(fox, tf, player, stack);
            }

            return true;
        }

        FoodProperties food = stack.get(DataComponents.FOOD);
        if (food != null && fox.getHealth() < fox.getMaxHealth()) {
            if (!client) {
                fox.heal(Math.max(1, food.nutrition()));
                tf.foxesstuff$playEatingSound();
                stack.consume(1, player);
                ((ServerLevel) fox.level()).sendParticles(ParticleTypes.HEART,
                        fox.getX(), fox.getY(0.7), fox.getZ(), 3, 0.3, 0.3, 0.3, 0.02);
            }
            return true;
        }

        if (!tf.foxesstuff$isFoxOwnedBy(player)) return false;

        if (stack.getItem() instanceof DyeItem dye) {
            DyeColor color = stack.getOrDefault(DataComponents.DYE, DyeColor.WHITE);
            if (color != tf.foxesstuff$getCollarColor()) {
                if (!client) {
                    tf.foxesstuff$setCollarColor(color);
                    stack.consume(1, player);
                }
                return true;
            }
            return false;
        }

        if (stack.isEmpty()) {
            if (!client) {
                if (player.isShiftKeyDown()) {
                    tf.foxesstuff$setFoxOrderedToSit(!tf.foxesstuff$isFoxOrderedToSit());
                } else if (player instanceof ServerPlayer sp) {
                    FoxPlatform.get().openFoxInventory(sp, fox);
                }
            }
            return true;
        }

        return false;
    }

    private static void handleCustomFood(Fox fox, TameableFox tameableFox, Player player, ItemStack stack) {
        tameableFox.foxesstuff$playEatingSound();
        stack.consume(1, player);

        RandomSource randomSource = player.getRandom();
        if (randomSource.nextBoolean()) {
            String variant = ModdedFoxVariants.getRandomVariant(randomSource);
            if (variant != null) {
                tameableFox.foxesstuff$setModdedVariant(variant);
            }
        } else {
            tameableFox.foxesstuff$setModdedVariant("");
            fox.setComponent(DataComponents.FOX_VARIANT, randomSource.nextBoolean() ? Fox.Variant.RED : Fox.Variant.SNOW);
        }
    }
}
